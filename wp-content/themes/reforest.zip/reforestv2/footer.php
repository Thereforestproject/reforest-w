    <div class="container-fluid">
        <footer class="bg-light bg" style="height: 50;">
            <div class="container">
                <ul class="nav justify-content-center">
                    <li class="nav-item align-self-center">
                        <a class="nav-link active" href="index.html">
                            <img src="http://localhost/reforest-w/wp-content/uploads/2019/11/reforest.png" height="24">
                        </a>
                    </li>
                </ul>
            </div>
        </footer>
    </div>
    
    <?php wp_footer(); ?>
</body>

</html>